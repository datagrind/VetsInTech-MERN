// Values for the loops
let forLoopValues = [];
for (let i = 0; i < 5; i++) {
    forLoopValues.push(i);
}

let whileLoopValues = [];
let i = 0;
while (i < 5) {
    whileLoopValues.push(i);
    i++;
}

let doWhileLoopValues = [];
i = 0;
do {
    doWhileLoopValues.push(i);
    i++;
} while (i < 5);

let forInLoopValues = [];
const person = { name: "John", age: 30 };
for (const key in person) {
    forInLoopValues.push(person[key]);
}

let forOfLoopValues = [];
const fruits = ["apple", "banana", "cherry"];
for (const fruit of fruits) {
    forOfLoopValues.push(fruit);
}

let forEachLoopValues = [];
const numbers = [1, 2, 3, 4, 5];
numbers.forEach(function (number) {
    forEachLoopValues.push(number);
});

// Display loop values in HTML
document.getElementById("forLoopValues").innerHTML = forLoopValues.map(value => `<li>${value}</li>`).join('');
document.getElementById("whileLoopValues").innerHTML = whileLoopValues.map(value => `<li>${value}</li>`).join('');
document.getElementById("doWhileLoopValues").innerHTML = doWhileLoopValues.map(value => `<li>${value}</li>`).join('');
document.getElementById("forInLoopValues").innerHTML = forInLoopValues.map(value => `<li>${value}</li>`).join('');
document.getElementById("forOfLoopValues").innerHTML = forOfLoopValues.map(value => `<li>${value}</li>`).join('');
document.getElementById("forEachLoopValues").innerHTML = forEachLoopValues.map(value => `<li>${value}</li>`).join('');
