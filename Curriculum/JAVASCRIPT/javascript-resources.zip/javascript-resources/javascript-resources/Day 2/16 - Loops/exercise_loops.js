// Tasks:

// 1. for Loop
// Multiplication Table Generator

//     Objective: Create a multiplication table for a number entered by the user.
//     Details:
//         Prompt the user to enter a number.
//         Use a for loop to iterate from 1 to 10.
//         In each iteration, multiply the user's number by the loop index and display the result in a formatted string (e.g., "5 x 2 = 10").
//         This helps students understand how to control the number of iterations and use the loop index in calculations.

// Creating HTML Elements

//     Objective: Dynamically generate a list of HTML list items (<li>).
//     Details:
//         Use a for loop to iterate a fixed number of times (e.g., 10).
//         In each iteration, create an HTML <li> element with content based on the loop index (e.g., "Item 1", "Item 2").
//         Append these items to an HTML <ul> or <ol> element.
//         This scenario shows how to combine JavaScript with HTML to manipulate the DOM.

// 2. while Loop
// Number Guessing Game

//     Objective: Implement a game where the user must guess a randomly generated number.
//     Details:
//         Generate a random number within a range.
//         Use a while loop to repeatedly ask the user to guess the number.
//         Continue looping until the user guesses correctly.
//         This exercise teaches conditional looping and handling user input.

// User Input Validation

//     Objective: Validate user input for a specific criterion.
//     Details:
//         Ask the user to input a username.
//         Use a while loop to check if the input meets certain conditions (e.g., non-empty, minimum length).
//         Keep prompting the user until a valid username is entered.
//         This shows how to use while loops for input validation.

// 3. do...while Loop
// Menu Selection

//     Objective: Implement a text-based menu system.
//     Details:
//         Present a list of options to the user, including an option to exit.
//         Use a do...while loop to handle user input and repeat the menu display after each action, until the user chooses to exit.
//         This demonstrates the use of do...while for guaranteed minimum iteration.

// Password Strength Checker

//     Objective: Ensure a user's password meets specific strength criteria.
//     Details:
//         Prompt the user to set a password.
//         Use a do...while loop to check if the password meets criteria (e.g., length, character types).
//         Loop until the user enters a strong password.
//         This is a practical scenario for understanding the do...while loop in user input scenarios.

// 4. for...in Loop
// Object Property Listing

//     Objective: Display properties of a JavaScript object.
//     Details:
//         Create an object with various properties (e.g., user profile data).
//         Use a for...in loop to iterate over the object properties.
//         Display each property name and its value.
//         This helps students understand how to iterate over object properties.

// Style Object Iteration

//     Objective: Apply styles to an element using a JavaScript object.
//     Details:
//         Create a JavaScript object representing CSS styles (e.g., { color: 'red', fontSize: '14px' }).
//         Use a for...in loop to iterate through the object and apply each style to an HTML element.
//         This teaches dynamic styling of DOM elements using JavaScript objects.

// 5. for...of Loop
// Array Element Processing

//     Objective: Process elements of an array to create a new array.
//     Details:
//         Start with an array of numbers.
//         Use a for...of loop to iterate through the array.
//         In each iteration, perform an operation (e.g., doubling the number) and add the result to a new array.
//         Display both the original and new arrays.
//         This scenario teaches array processing and creating new arrays from existing data.

// Social Media Posts

//     Objective: Display a list of social media posts.
//     Details:
//         Create an array of objects, each representing a social media post (with properties like title, content, author).
//         Use a for...of loop to iterate over the array.
//         Display each post's details in a formatted way.
//         This scenario is great for understanding how to handle and display array data.

// 6. forEach Loop
// Data Analysis

//     Objective: Perform statistical analysis on survey data.
//     Details:
//         Provide an array of objects, each representing a survey response.
//                 Use the forEach loop to iterate through the array and calculate statistics (e.g., average ratings).

//                 Extended Activities:
// 1. for Loop Extension Activities
// Enhanced Multiplication Table Generator

//     Advanced Objective: Generate a complete multiplication table up to a user-specified number.
//     Extended Tasks:
//         Create a nested for loop: the outer loop for the multiplier (1 to user input) and the inner loop for the multiplicand (1 to 10).
//         Display the full multiplication table in a formatted grid layout using HTML or console output.

// Dynamic Quiz Application

//     Advanced Objective: Create a simple quiz application with a set of questions and options.
//     Extended Tasks:
//         Use an array of objects for quiz questions, where each object contains the question, a set of options, and the correct answer.
//         Iterate through this array using a for loop, displaying each question and capturing user responses.
//         At the end, use another for loop to tally the correct responses and display the user's score.

// 2. while Loop Extension Activities
// Investment Calculator

//     Advanced Objective: Calculate how long it takes for an investment to reach a desired value.
//     Extended Tasks:
//         Ask the user for the principal amount, annual interest rate, and target amount.
//         Use a while loop to simulate the investment over time.
//         Increment a year counter in each iteration until the target is reached or exceeded, then display the number of years required.

// Recursive Menu System

//     Advanced Objective: Implement a recursive menu system that can handle multiple levels of submenus.
//     Extended Tasks:
//         Design a multi-level menu structure using nested objects or arrays.
//         Use a while loop to present the current menu and capture user input.
//         If a submenu is selected, recursively call the menu function with the submenu as the argument.

// 3. do...while Loop Extension Activities
// Command-Line Drawing Tool

//     Advanced Objective: Implement a basic command-line drawing tool.
//     Extended Tasks:
//         Prompt the user for various commands (like draw line, rectangle, clear).
//         Implement each drawing command within the do...while loop.
//         After executing a command, redraw the canvas and prompt for the next command until the user chooses to exit.

// Interactive Learning Console

//     Advanced Objective: Create an interactive console for learning programming concepts.
//     Extended Tasks:
//         Design a series of mini-lessons or exercises (like math problems, logic puzzles).
//         Use a do...while loop to navigate through lessons and accept user inputs for exercises.
//         Provide immediate feedback and allow users to repeat or move to the next lesson.

// 4. for...in Loop Extension Activities
// JSON Data Explorer

//     Advanced Objective: Build a tool to explore and display JSON data.
//     Extended Tasks:
//         Load a complex JSON object (like a response from a web API).
//         Use a for...in loop to iterate through the object and display its structure.
//         Implement features to drill down into nested objects and arrays.

// Dynamic Form Builder

//     Advanced Objective: Create a dynamic form builder based on a JavaScript object.
//     Extended Tasks:
//         Define a form structure using a JavaScript object (with fields, types, labels, etc.).
//         Use a for...in loop to iterate over this object and generate corresponding HTML form elements dynamically.
//         Implement validation and submission logic for the form.

// 5. for...of Loop Extension Activities
// Data Visualization Tool

//     Advanced Objective: Develop a basic tool to visualize array data.
//     Extended Tasks:
//         Start with an array of numbers or objects containing data points.
//         Use a for...of loop to process these data points and generate a simple chart or graph (like a bar chart or line graph).
//         Use HTML and CSS to display the visualized data.

// Interactive Story Game

//     Advanced Objective: Create a text-based interactive story or adventure game.
//     Extended Tasks:
//         Design a story with multiple paths stored in an array.
//         Use a for...of loop to progress through the story, allowing the user to make choices that determine the next part of the story.

// 6. forEach Loop Extension Activities
// Real-time Data Monitoring Dashboard

//     Advanced Objective: Build a dashboard for monitoring real-time data (like stock prices, weather updates).
//     Extended Tasks:
//         Use an array to store the latest data points.
//         Implement a mechanism to update this array periodically.
//         Use forEach to iterate through the array and update the dashboard with the latest information.