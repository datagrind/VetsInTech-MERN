// Objective

// Create a web page with various elements to which you will attach JavaScript event handlers, demonstrating understanding of common events, event object properties, and event propagation.

// Tasks

//     Button Click Event
//         Attach a click event listener to the button. When clicked, display an alert box with a message.

//     Mouse Events
//         Attach mouseover and mouseout events to the mouseArea div. Change the background color of the div when the mouse hovers over it and revert when it leaves.

//     Keyboard Event
//         Attach a keyup event listener to the text input field. Display the last key pressed in the log div.

//     Preventing Default Behavior
//         Add a form with a submit button. Use event.preventDefault() to stop the form from submitting.

//     Event Propagation
//         Create a parent div with several child elements. Use event delegation on the parent to handle clicks on the child elements.