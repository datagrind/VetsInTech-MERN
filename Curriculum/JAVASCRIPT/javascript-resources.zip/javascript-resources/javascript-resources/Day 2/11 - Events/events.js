// Get a reference to the button element
var button = document.getElementById("myButton");

// Get a reference to the paragraph element where the output will be displayed
var output = document.getElementById("output");

// Define an event handler function
function buttonClickHandler() {
  // Change the text displayed in the paragraph
  output.textContent = "Button clicked!";
}

// Attach the event handler to the button's click event
button.addEventListener("click", buttonClickHandler);
