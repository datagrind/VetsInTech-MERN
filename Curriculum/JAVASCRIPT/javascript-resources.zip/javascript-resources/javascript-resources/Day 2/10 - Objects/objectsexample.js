// Define a person object
var person = {
    name: "Alice",
    age: 30,
    city: "New York",
  };
  
  // Access object properties and display them in the HTML page
  document.getElementById("name").textContent = person.name;
  document.getElementById("age").textContent = person.age;
  document.getElementById("city").textContent = person.city;
  