// Objective

// Gain hands - on experience with creating, modifying, accessing, and utilizing JavaScript objects, including using object-oriented programming features and JSON.

// Tasks

    // Creating and Modifying Objects
    //     Create an object named person using object literal syntax with properties name and age.
    //     Modify the age property and add a new property hobby.
    //     Console.log the object to see the changes.

    // Accessing Properties
    //     Access the properties of the person object using both dot and bracket notation.
    //     Console.log each property.

    // Using Constructor Functions
    //     Define a constructor function Animal with properties species and sound.
    //     Create an instance of Animal and log it to the console.

    // Class and Inheritance
    //     Define a class Vehicle with properties type and wheels.
    //     Extend this class with a subclass Car that has an additional property brand.
    //     Create an instance of Car and log it to the console.

    // Iterating Over Object Properties
    //     Use a for...in loop to iterate over the person object and print each property and its value.

    // Working with Object Methods
    //     Add a method introduce to the person object that logs a greeting message.
    //     Call this method.

    // Prototypal Inheritance
    //     Add a method to the Animal prototype and call it on the instance created earlier.

    // JSON Conversion
    //     Convert the person object to a JSON string and back to an object.
    //     Log both the string and the new object.

    // Object Destructuring
    //     Destructure the person object into two separate variables for name and age and log them.
