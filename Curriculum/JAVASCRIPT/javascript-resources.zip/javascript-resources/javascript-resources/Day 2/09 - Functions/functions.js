function calculateSum(a, b) {
    return a + b;
  }
  
  // Call the function and store the result in a variable
  var result = calculateSum(5, 8);
  
  // Display the result in the HTML page
  var resultElement = document.getElementById("result");
  resultElement.textContent = "The sum is: " + result;
  