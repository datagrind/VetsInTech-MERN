// Objective:

// Understand and create various types of JavaScript functions, ranging from simple functions to higher-order functions.

// Tasks:

    // Simple Function Declaration:
    //     Create a function named sayHello that takes a name as a parameter and logs "Hello, [name]!".
    //     Invoke sayHello with a name of your choice.

    // Function with Return Statement:
    //     Create a function sum that takes two parameters, adds them, and returns the result.
    //     Call sum with two numbers and log the returned value.

    // Function Expressions:
    //     Create a function expression findMax that takes two numbers and returns the larger number.
    //     Invoke findMax and log the result.

    // Arrow Functions:
    //     Define an arrow function square that takes a number and returns its square.
    //     Call square with a number and log the result.

    // Function Scope:
    //     Create a function testScope and declare a variable inside it. Log the variable inside and outside the function to demonstrate scope.

    // Function Hoisting:
    //     Demonstrate function hoisting by calling a function hoistedFunction before its declaration. Then declare hoistedFunction and log a message.

    // Recursive Function:
    //     Write a recursive function calculateFactorial that computes the factorial of a number.
    //     Invoke calculateFactorial with a positive integer and log the result.

    // Higher-Order Function:
    //     Create a higher-order function modifyArray that takes an array and a function as arguments. The function argument should modify the elements of the array.
    //     Test modifyArray with a simple function (like doubling numbers) and log the modified array.