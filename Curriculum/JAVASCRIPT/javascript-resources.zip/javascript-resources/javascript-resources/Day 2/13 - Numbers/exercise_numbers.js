// Objective

// Create a series of engaging tasks for students to practice and understand the usage of numbers in JavaScript, including number creation, built-in methods, properties, and the Math object.
// Tasks

//     Creating and Displaying Numbers
//         Create various types of numbers (integer, floating-point) and display them.

//     Exploring Number Methods
//         Apply methods like toString(), toFixed(), toPrecision(), parseInt(), parseFloat(), isNaN(), and isFinite() on different numbers and display the results.

//     Math Object Functions
//         Use functions from the Math object such as Math.abs(), Math.round(), Math.floor(), Math.ceil(), Math.max(), Math.min(), Math.random(), and Math.pow().
//         Perform calculations and display the outcomes.

//     Working with Number Properties
//         Explore properties like Number.MAX_VALUE, Number.MIN_VALUE, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY, and Number.NaN.
//         Demonstrate scenarios where these properties become relevant.

//     NaN and Infinity
//         Create examples where operations result in NaN and Infinity, and discuss how to handle these cases.

//     Extra Time? Building a Mini Calculator
//         Create a simple calculator that uses various Math methods and number methods.
//         Include features like addition, subtraction, multiplication, division, square root, and power calculations.