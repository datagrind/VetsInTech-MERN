// Original number
var originalNumber = 5.87;

// Get references to HTML elements
var originalNumberElement = document.getElementById("originalNumber");
var squareElement = document.getElementById("square");
var roundedElement = document.getElementById("rounded");
var randomNumberElement = document.getElementById("randomNumber");

// Display the original number
originalNumberElement.textContent = originalNumber;

// Calculate the square of the number
var square = originalNumber * originalNumber;
squareElement.textContent = square;

// Round the number to the nearest integer
var rounded = Math.round(originalNumber);
roundedElement.textContent = rounded;

// Generate a random number between 1 and 100
var randomNumber = Math.floor(Math.random() * 100) + 1;
randomNumberElement.textContent = randomNumber;
