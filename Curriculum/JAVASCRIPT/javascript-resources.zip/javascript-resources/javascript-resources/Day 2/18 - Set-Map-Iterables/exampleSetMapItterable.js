// Set Example
const mySet = new Set();
mySet.add(1);
mySet.add(2);
mySet.add(3);
mySet.add(2); // Adding a duplicate value will be ignored

// Map Example
const myMap = new Map();
myMap.set("name", "John");
myMap.set("age", 30);

// Display Set values in HTML
const setValuesList = document.getElementById("setValues");
for (const value of mySet) {
    const li = document.createElement("li");
    li.textContent = value;
    setValuesList.appendChild(li);
}

// Display Map key-value pairs in HTML
const mapValuesList = document.getElementById("mapValues");
for (const [key, value] of myMap) {
    const li = document.createElement("li");
    li.textContent = `${key}: ${value}`;
    mapValuesList.appendChild(li);
}
