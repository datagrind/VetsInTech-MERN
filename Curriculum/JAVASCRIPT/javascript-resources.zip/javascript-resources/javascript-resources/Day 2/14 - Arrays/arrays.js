// Original array of numbers
var numbers = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5];

// Get references to HTML elements
var originalArrayElement = document.getElementById("originalArray");
var sortedArrayElement = document.getElementById("sortedArray");
var squaresElement = document.getElementById("squares");
var evenNumbersElement = document.getElementById("evenNumbers");

// Display the original array
originalArrayElement.textContent = numbers.join(", ");

// Sort the array in ascending order
numbers.sort(function (a, b) {
  return a - b;
});
sortedArrayElement.textContent = numbers.join(", ");

// Calculate the square of each number
var squares = numbers.map(function (num) {
  return num * num;
});
squaresElement.textContent = squares.join(", ");

// Filter even numbers
var evenNumbers = numbers.filter(function (num) {
  return num % 2 === 0;
});
evenNumbersElement.textContent = evenNumbers.join(", ");
