// Objective

// Develop a set of interactive exercises for students to gain hands-on experience with JavaScript arrays, focusing on creation, manipulation, and iteration techniques.
// Tasks

//     Creating and Displaying Arrays
//         Create arrays with different data types, including nested arrays.
//         Display the created arrays.

//     Manipulating Array Elements
//         Use methods like push(), pop(), shift(), unshift(), concat(), slice(), and splice() to manipulate arrays.
//         Display the results after each operation.

//     Joining and Sorting Arrays
//         Utilize join() to merge array elements into a string.
//         Sort an array of numbers using a custom comparison function in sort().

//     Iterating Over Arrays
//         Implement for loops and forEach() to iterate over array elements.
//         Perform simple operations on each element during iteration.

//     Advanced Array Methods
//         Explore map(), filter(), and reduce() through practical examples.
//         Display the new arrays or results obtained from these methods.

//     Creating a Dynamic Shopping List
//         Build a dynamic shopping list where items can be added, removed, and sorted.
//         Implement features like searching for an item using indexOf() and updating item quantities.