// Using Break
let breakValues = [];
for (let i = 0; i < 5; i++) {
    if (i === 3) {
        break; // Exit the loop when i is 3
    }
    breakValues.push(i);
}

// Using Continue
let continueValues = [];
for (let i = 0; i < 5; i++) {
    if (i === 2) {
        continue; // Skip iteration when i is 2
    }
    continueValues.push(i);
}

// Display loop values in HTML
document.getElementById("breakValues").innerHTML = breakValues.map(value => `<li>${value}</li>`).join('');
document.getElementById("continueValues").innerHTML = continueValues.map(value => `<li>${value}</li>`).join('');
