// Objective

// Perform a series of tasks to practice string manipulation in JavaScript, covering string creation, methods, search, templates, escape characters, and concatenation.
// Tasks

//     String Creation
//         Create strings using both single and double quotes.
//         Display them in the console to verify their creation.

//     Using String Methods
//         Create a string and apply various methods like toUpperCase(), toLowerCase(), charAt(), substring(), indexOf(), lastIndexOf(), split(), trim(), and replace().
//         Display the results of each method in the console.

//     String Search with Regular Expressions
//         Write a function that takes a string and searches for an email pattern using regular expressions.
//         Test the function with different strings and display whether an email was found or not.

//     Working with Template Literals
//         Create a template literal with placeholders for a person’s name and age.
//         Use the template to generate a personalized greeting and display it.

//     Escape Characters in Strings
//         Create a string that includes special characters, like quotes or new lines, using escape characters.
//         Display the string to show how the escape characters are interpreted.

//     String Concatenation
//         Demonstrate string concatenation using both the + operator and template literals.
//         Compare the results to understand the differences.