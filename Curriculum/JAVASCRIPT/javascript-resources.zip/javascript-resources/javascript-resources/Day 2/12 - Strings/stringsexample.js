// Original string
var originalString = "JavaScript is a versatile language.";

// Get references to HTML elements
var originalStringElement = document.getElementById("originalString");
var uppercaseElement = document.getElementById("uppercase");
var lowercaseElement = document.getElementById("lowercase");
var substringElement = document.getElementById("substring");
var searchResultElement = document.getElementById("searchResult");

// Display the original string
originalStringElement.textContent = originalString;

// Convert to uppercase
var uppercaseString = originalString.toUpperCase();
uppercaseElement.textContent = uppercaseString;

// Convert to lowercase
var lowercaseString = originalString.toLowerCase();
lowercaseElement.textContent = lowercaseString;

// Extract a substring
var substring = originalString.substring(4, 14); // Get characters from index 4 to 13
substringElement.textContent = substring;

// Search for a pattern using regular expression
var pattern = /versatile/;
var searchResult = originalString.search(pattern) >= 0 ? "Pattern found" : "Pattern not found";
searchResultElement.textContent = searchResult;
