// Sample data
var day = "Monday";

// Get references to HTML elements
var dayElement = document.getElementById("day");
var typeOfDayElement = document.getElementById("typeOfDay");

// Display the day
dayElement.textContent = day;

// Determine the type of day using a switch statement
var typeOfDay;

switch (day) {
  case "Monday":
    typeOfDay = "It's the start of the workweek.";
    break;
  case "Friday":
    typeOfDay = "It's almost the weekend!";
    break;
  default:
    typeOfDay = "It's a regular day.";
}

typeOfDayElement.textContent = typeOfDay;
