// Sample data
var age = 25;
var hasDriverLicense = true;

// Get references to HTML elements
var ageElement = document.getElementById("age");
var hasLicenseElement = document.getElementById("hasLicense");
var eligibilityElement = document.getElementById("eligibility");

// Display the age and license status
ageElement.textContent = age;
hasLicenseElement.textContent = hasDriverLicense ? "Yes" : "No";

// Check eligibility using conditional statements
if (age >= 18 && hasDriverLicense) {
  eligibilityElement.textContent = "You are eligible to drive.";
} else if (age >= 16) {
  eligibilityElement.textContent = "You can get a learner's permit.";
} else {
  eligibilityElement.textContent = "You are too young to drive.";
}
