// Tasks:
// 1. Basic if-else Structures

//     Scenario: Age Verification for Content Access
//         Implement an if-else statement to check if the user's age is above 18.
//         If true, display a message granting access to content; if false, display an age restriction warning.

//     Scenario: Simple Password Checker
//         Create a predefined password string.
//         Use an if-else statement to check if the user input matches the password.
//         Display a success message or an error message based on the match.

// 2. Multiple Conditions with else if

//     Scenario: Grading System
//         Define a numeric score and assign a grade (A, B, C, D, F) using else if blocks.
//         Each grade range (e.g., 90-100 for A) triggers a different console log message with the grade.

//     Scenario: Online Shopping Discounts
//         Based on the total shopping cart value, apply different discount percentages using else if.
//         For instance, over $100 gets 10% off, over $200 gets 20% off, etc.

// 3. Using Logical Operators

//     Scenario: Membership Discount Eligibility
//         Check if a shopper is eligible for an extra discount based on their age (>60) and membership status (isMember).
//         Use the && operator to combine these conditions.

//     Scenario: Weekend Activity Suggestion
//         Suggest activities based on weather (sunny, rainy) and day of the week (weekend or weekday).
//         Use || and && operators to handle different combinations.

// 4. Implementing switch Statements

//     Scenario: User Role Permissions
//         Create different user roles (admin, user, guest).
//         Use a switch statement to display specific permissions for each role.

//     Scenario: Theme Selector
//         Let users choose a theme (light, dark, contrast) for a webpage.
//         Use a switch statement to apply the chosen theme.

// 5. Comparing == vs. ===

//     Scenario: Input Type Validation
//         Create a form that accepts numeric input.
//         Use == and === to compare input, demonstrating how each operator treats type coercion.

//     Scenario: Quiz Answer Checker
//         Implement a quiz with string and number answers.
//         Compare student answers using == and === to show how type coercion affects the results.

// 6. Building a Mini Quiz

//     Scenario: JavaScript Basics Quiz
//         Create a set of multiple-choice questions about JavaScript basics.
//         Use conditional statements to check the answers and provide instant feedback on each question.

// Extension Activities

//     Function for Filtering Array
//         Write a function that filters an array of objects based on a property value using conditional statements.

//     Refactoring Challenge
//         Provide a complex if-else structure and challenge students to refactor it into a switch statement, and vice versa.

//     Interactive Game: Rock-Paper-Scissors
//         Develop a simple rock-paper-scissors game where the user's choice is compared against a random computer choice using if-else or switch statements.