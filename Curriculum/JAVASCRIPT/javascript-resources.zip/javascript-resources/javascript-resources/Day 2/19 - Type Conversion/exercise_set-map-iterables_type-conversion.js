// Tasks:

// Sets in JavaScript
// Exercise: Unique Item Finder

//     Objective: Create a function that takes an array of items (which may contain duplicates) and returns an array of unique items using a Set.
//     Tasks:
//         Accept an array of items (can be numbers, strings, etc.).
//         Create a Set from the array to remove duplicates.
//         Convert the Set back into an array and return it.
//     Example:
//         Input: [1, 2, 2, 3, 4, 4, 4, 5]
//         Output: [1, 2, 3, 4, 5]

// Maps in JavaScript
// Exercise: User Profile Updater

//     Objective: Implement a system to manage user profiles using a Map, where the key is the user ID and the value is an object containing user details.
//     Tasks:
//         Create a Map to hold user data.
//         Implement functions to add, update, and delete user profiles.
//         Create a function to display the profile of a specified user.
//     Example:
//         Add user: { id: 'user1', name: 'Alice', age: 25 }
//         Update user: 'user1' with { name: 'Alice Smith', age: 26 }
//         Delete user: 'user1'

// Iterables in JavaScript
// Exercise: Custom Iterable Collection

//     Objective: Create a custom iterable collection that can be iterated using a for...of loop.
//     Tasks:
//         Define a custom collection class or object.
//         Implement the iterable protocol by defining the Symbol.iterator method.
//         Demonstrate iterating over the collection with a for...of loop.
//     Example:
//         Collection: A set of books or movies.
//         Iterate and display each item in the collection.

// Type Conversion in JavaScript
// Exercise: Data Type Converter

//     Objective: Build a utility that takes input from the user and converts it to different data types (string, number, boolean).
//     Tasks:
//         Accept user input as a string.
//         Implement functions to convert the input to a number, a string, and a boolean.
//         Display the converted values along with their types.
//     Example:
//         Input: "123"
//         Output: Number: 123, String: "123", Boolean: true

// typeof Operator in JavaScript
// Exercise: Type Detective

//     Objective: Create a function that analyzes variables and reports their data types using the typeof operator.
//     Tasks:
//         Accept a variable or an expression.
//         Use the typeof operator to determine its data type.
//         Display the type information to the user.
//     Example:
//         Input: 42
//         Output: "number"