// Type Conversion Example
const numString = "42";
const num = parseInt(numString);
const bool = Boolean(0);

// typeof Example
const values = [42, "Hello", true, {}, function(){}];
const types = values.map(value => typeof value);

// Display Type Conversion values in HTML
const conversionValuesList = document.getElementById("conversionValues");
const conversionItems = [
    `parseInt("42") as number: ${num}`,
    `Boolean(0) as Boolean: ${bool}`
];

conversionItems.forEach(item => {
    const li = document.createElement("li");
    li.textContent = item;
    conversionValuesList.appendChild(li);
});

// Display typeof values in HTML
const typeofValuesList = document.getElementById("typeofValues");
types.forEach(type => {
    const li = document.createElement("li");
    li.textContent = type;
    typeofValuesList.appendChild(li);
});
