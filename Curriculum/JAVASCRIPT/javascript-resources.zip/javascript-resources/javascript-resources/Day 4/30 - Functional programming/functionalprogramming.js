// Pure Functions

// Check if a number is even
function isEven(number) {
    return number % 2 === 0;
}

// Parse and filter the list of numbers
function parseAndFilter(inputText) {
    const numbers = inputText.split(',').map(Number);
    return numbers.filter(isEven);
}

// Calculate the sum of numbers
function calculateSum(numbers) {
    return numbers.reduce((acc, number) => acc + number, 0);
}

// Event Listener

document.getElementById('calculateButton').addEventListener('click', function () {
    const numbersInput = document.getElementById('numbersInput').value;
    const resultElement = document.getElementById('result');

    // Parse, filter, and calculate sum in a functional way
    const result = calculateSum(parseAndFilter(numbersInput));

    resultElement.textContent = result;
});
