// Tasks:

// Exercise 1: Pure Functions:
//     Objective: Understand the concept of pure functions.
//     Create a pure function that squares a number.

// Exercise 2: Immutability:
//     Objective: Learn about immutability in functional programming.
//     Create an immutable array of numbers and display the results of various operations on it.

// Exercise 3: Higher-Order Functions:
//     Objective: Explore higher - order functions like map, filter, and reduce.
//     Use these functions to manipulate an array of numbers.

// Exercise 4: Function Composition:
//     Objective: Practice function composition.
//     Create a function that adds two numbers and then squares the result.

// Exercise 5: Recursion:
//     Objective: Learn about recursion in functional programming.
//     Create a recursive function that calculates the factorial of a number.

// Exercise 6: Closures:
//     Objective: Explore the use of closures in functional programming.
//     Create a function that returns a function and then invoke it.