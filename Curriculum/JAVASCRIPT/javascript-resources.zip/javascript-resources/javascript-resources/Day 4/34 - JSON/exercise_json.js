// Objective
// Create a .json file with structured data and then write a JavaScript program to read and process this data.

// Tasks:

// Part 1: Create the JSON File
//     File Name: data.json

//     Content: Create a JSON file representing a collection of books. Each book should have the following properties:
//         id: A unique identifier (number).
//         title: The title of the book (string).
//         author: The name of the author (string).
//         year: The year of publication (number).
//         genres: An array of genres(array of strings).
//         (you should have a minimum of 5 books)

// Part 2: Create the JavaScript File

//     Task: Write a script to read the data.json file and perform the following operations:
//         Load the JSON data into your JavaScript code.
//         Log the entire JSON object to the console.
//         Iterate through the array of books and log each book's title and author.

//     Methods to Explore:
//         You may use Axios to read the JSON file.
//         Use JSON.parse() to convert the JSON string into a JavaScript object.