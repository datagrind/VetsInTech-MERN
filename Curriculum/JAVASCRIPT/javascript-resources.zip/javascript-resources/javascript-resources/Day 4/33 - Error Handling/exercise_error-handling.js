// Tasks:

// Exercise 1: Using try...catch:
//     Objective: Implement try...catch blocks to handle potential errors gracefully.
//     Create a try...catch block that handles a potential error and displays a message to the user.

// Exercise 2: Throwing Custom Errors:
//     Objective: Use the throw statement to create and handle custom errors.
//     Create a custom error and throw it inside a try...catch block.

// Exercise 3: Extending the Error Object:
//     Objective: Extend the built -in Error object to create a custom error type.
//     Create a custom error type that extends the built-in Error object.

// Exercise 4: Async/Await with Try-Catch:
//     Objective: Handle errors in asynchronous code using async/await with try...catch.
//     Create an asynchronous function that throws an error and handle it using try...catch.

// Exercise 5: Global Error Handler:
//     Objective: Set up a global error handler for uncaught exceptions.
//     Create a global error handler that displays the error message in the console.

// Exercise 6: Promise Error Handling:
//     Objective: Handle errors in Promises using.catch().
//     Create a Promise that throws an error and handle it using.catch().


