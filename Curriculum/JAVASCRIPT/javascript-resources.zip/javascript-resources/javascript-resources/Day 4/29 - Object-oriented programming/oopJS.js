// JavaScript code (the classes and interaction)
class Shape {
    constructor(color) {
      this.color = color;
    }
  
    describe() {
      return `This shape is ${this.color}.`;
    }
  }
  
  class Rectangle extends Shape {
    constructor(color, width, height) {
      super(color);
      this.width = width;
      this.height = height;
    }
  
    area() {
      return this.width * this.height;
    }
  
    describe() {
      return `This rectangle is ${this.color}, has width ${this.width}, height ${this.height}, and area ${this.area()}.`;
    }
  }
  
  class Circle extends Shape {
    constructor(color, radius) {
      super(color);
      this.radius = radius;
    }
  
    area() {
      return Math.PI * Math.pow(this.radius, 2);
    }
  
    describe() {
      return `This circle is ${this.color}, has radius ${this.radius}, and area ${this.area()}.`;
    }
  }
  
  const createShapeButton = document.getElementById('create-shape');
  const shapeColorInput = document.getElementById('shape-color');
  const shapeTypeSelect = document.getElementById('shape-type');
  const shapesContainer = document.getElementById('shapes-container');
  
  createShapeButton.addEventListener('click', () => {
    const color = shapeColorInput.value;
    const type = shapeTypeSelect.value;
  
    if (type === 'rectangle') {
      const rectangle = new Rectangle(color, 5, 10);
      displayShape(rectangle);
    } else if (type === 'circle') {
      const circle = new Circle(color, 4);
      displayShape(circle);
    }
  });
  
  function displayShape(shape) {
    const shapeElement = document.createElement('div');
    shapeElement.textContent = shape.describe();
    shapesContainer.appendChild(shapeElement);
  }
  