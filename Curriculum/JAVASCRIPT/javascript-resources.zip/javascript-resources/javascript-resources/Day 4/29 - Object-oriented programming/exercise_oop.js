// Tasks:

// Exercise 1: Constructors and Object Creation:
// Objective: Learn to create objects using constructor functions.
// Create a constructor function for a Person object. Each person should have a firstName, lastName, favoriteColor, favoriteNumber and favoriteFoods (which should be an array).

// Exercise 2: Prototypes:
// Objective: Understand how to add methods to an object's prototype.
// Add a method called fullName to the Person prototype. This method should return the firstName and lastName property of a person.

// Exercise 3: Inheritance:
// Objective: Practice prototypal inheritance in JavaScript.
// Create a constructor function for a Vehicle. Each vehicle should have a make, model and year property.

// Exercise 4: ES6 Classes:
// Objective: Implement OOP using ES6 class syntax.
// Create a class for a Vehicle. Each vehicle should have a make, model and year property.

// Exercise 5: Understanding 'this' in Methods:
// Objective: Explore how the this keyword behaves in different contexts.
// Create a Person constructor that has three properties: name, job, and age.
