const Singleton = (function () {
    let instance;
    
    function createInstance() {
      // Private methods and variables
      return {
        // Public methods and variables
      };
    }
  
    return {
      getInstance: function () {
        if (!instance) {
          instance = createInstance();
        }
        return instance;
      },
    };
  })();
  
  module.exports = Singleton;
  