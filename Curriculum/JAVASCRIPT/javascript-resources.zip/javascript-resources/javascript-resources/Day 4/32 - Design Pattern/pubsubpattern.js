const pubsub = (function () {
    const subscribers = {};
  
    return {
      subscribe: function (topic, callback) {
        if (!subscribers[topic]) {
          subscribers[topic] = [];
        }
        subscribers[topic].push(callback);
      },
      publish: function (topic, data) {
        if (subscribers[topic]) {
          subscribers[topic].forEach((callback) => callback(data));
        }
      },
    };
  })();
  
  module.exports = pubsub;
  