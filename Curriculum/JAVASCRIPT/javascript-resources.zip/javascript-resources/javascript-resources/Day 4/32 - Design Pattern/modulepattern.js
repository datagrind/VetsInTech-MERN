const Module = (function () {
    // Private variables and functions
  
    return {
      // Public variables and functions
    };
  })();
  
  module.exports = Module;
  