class Subject {
    constructor() {
      this.observers = [];
    }
  
    addObserver(observer) {
      this.observers.push(observer);
    }
  
    notify(message) {
      this.observers.forEach((observer) => observer.update(message));
    }
  }
  
  class Observer {
    update(message) {
      console.log(`Received message: ${message}`);
    }
  }
  
  module.exports = { Subject, Observer };
  