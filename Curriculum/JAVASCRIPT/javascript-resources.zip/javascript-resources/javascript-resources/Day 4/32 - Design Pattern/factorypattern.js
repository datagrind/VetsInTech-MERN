function createObject(type) {
    if (type === 'A') {
      return new ObjectA();
    } else if (type === 'B') {
      return new ObjectB();
    }
  }
  
  module.exports = createObject;
  