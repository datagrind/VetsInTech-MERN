// Tasks:

// Exercise 1: Singleton Pattern:
//     Objective: Implement a Singleton pattern to ensure a class has only one instance.
    // Create a Singleton class that can only be instantiated once.

// Exercise 2: Module Pattern:
//     Objective: Create a Module pattern to encapsulate private and public members.
//     Create a module that creates a private variable and returns a public function that can modify that variable.

// Exercise 3: Factory Pattern:
//     Objective: Implement a Factory pattern to create objects without specifying the exact class.
//     Create a factory that returns different types of cars based on the input.

// Exercise 4: Constructor Pattern:
//     Objective: Use the Constructor pattern to create objects with shared methods.
//     Create a constructor function that creates a car object with a shared method.

// Exercise 5: Observer Pattern:
//     Objective: Implement the Observer pattern to create a one - to - many dependency.
//     Create a class that allows other classes to subscribe to events and trigger them.

// Exercise 6: Pub-Sub Pattern:
//     Objective: Explore the Publish - Subscribe pattern for event handling.
//     Create a class that allows other classes to subscribe to events and trigger them.

// Exercise 7: Decorator Pattern:
//     Objective: Use the Decorator pattern to dynamically add functionality.
//     Create a class that adds a new method to an existing object.