function performOperation(num1, num2, operation, callback) {
    let result;
    if (operation === 'add') {
      result = num1 + num2;
    } else if (operation === 'subtract') {
      result = num1 - num2;
    } else if (operation === 'multiply') {
      result = num1 * num2;
    } else if (operation === 'divide') {
      if (num2 === 0) {
        callback('Division by zero is not allowed', null);
        return;
      }
      result = num1 / num2;
    } else {
      callback('Invalid operation', null);
      return;
    }
    callback(null, result);
  }
  
  const resultContainer = document.getElementById('result-container');
  
  function displayResult(err, result) {
    if (err) {
      resultContainer.innerHTML = 'Error: ' + err;
    } else {
      resultContainer.innerHTML = 'Result: ' + result;
    }
  }
  
  function attachOperationClickEvent(operation) {
    const operationButton = document.getElementById(operation);
    operationButton.addEventListener('click', function () {
      const num1 = parseFloat(document.getElementById('num1').value);
      const num2 = parseFloat(document.getElementById('num2').value);
      performOperation(num1, num2, operation, displayResult);
    });
  }
  
  // Attach event listeners for each operation
  attachOperationClickEvent('add');
  attachOperationClickEvent('subtract');
  attachOperationClickEvent('multiply');
  attachOperationClickEvent('divide');
  