// Tasks:

// Exercise 1: Basic Callback Usage:
//     Objective: Learn to use callbacks for simple asynchronous tasks.
//     Create a basic function that accepts a callback as a parameter.Inside the function, call the callback and pass in a message of your choice.Then call the function and pass in an anonymous callback function that alerts the message.

// Exercise 2: Error-First Callbacks:
//     Objective: Understand and implement the "error-first" callback pattern.
//     Similar to the first exercise, create a basic function that accepts a callback as a parameter. Inside the function, create 2 variables, an error set to null and data set to Fetched data.  Then create a comment that says "error = "Something went wrong", call the callback and pass in error and data. Then call the function and pass in an anonymous callback function that takes in error and data and then a conditional that if an error is present it sends the error to the console otherwise it sends the data.

// Exercise 3: Avoiding Callback Hell:
//     Objective: Practice writing clean and maintainable code while using multiple callbacks.
//     Create 2 functions that use callbacks.The first function should use a callback to print the string "This is the first message".The second function should use a callback to print the string "This is the second message". The second function should be called inside the first function call.

// Exercise 4: Event-driven Callbacks:
//     Objective: Implement callbacks in response to DOM events.
//     This one will require an HTML page (exercise_callbacks.html). Inside the HTML create a button with the text "Click Me". When the button is clicked, display an alert with the message "Button clicked!".

// Exercise 5: Nested Callbacks and Error Handling:
//     Objective: Manage multiple nested callbacks and handle errors effectively.
//     Create a function that accepts a callback as a parameter. Inside the function, create a variable and set it equal to the string "Hello". Then call the callback and pass in the variable. Then create a second function that accepts a callback as a parameter. Inside the function, create a variable and set it equal to the string "Goodbye". Then call the callback and pass in the variable. Then call the first function and pass in the second function as a callback. Then call the first function again but this time pass in an anonymous callback function that takes in an error and a data parameter. Inside the function, check if the error is present and if so, send the error to the console. Otherwise print the data to the console.

