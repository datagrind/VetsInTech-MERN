const apiUrl = 'https://jsonplaceholder.typicode.com/posts/1';

function fetchDataFromAPI(callback) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', apiUrl, true);
  
  xhr.onload = function () {
    if (xhr.status === 200) {
      callback(null, JSON.parse(xhr.responseText));
    } else {
      callback('Error fetching data from the API', null);
    }
  };
  
  xhr.onerror = function () {
    callback('Network error while fetching data', null);
  };
  
  xhr.send();
}

document.getElementById('fetch-data').addEventListener('click', function () {
  fetchDataFromAPI(function (err, data) {
    const dataContainer = document.getElementById('data-container');
    if (err) {
      dataContainer.innerHTML = 'Error: ' + err;
    } else {
      dataContainer.innerHTML = 'API Data: ' + JSON.stringify(data, null, 2);
    }
  });
});
