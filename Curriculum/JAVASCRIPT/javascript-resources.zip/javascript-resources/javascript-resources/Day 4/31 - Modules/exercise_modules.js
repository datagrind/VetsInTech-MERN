// Tasks:

// Exercise 1: CommonJS Modules:
//     Objective: Learn how to import and export modules using CommonJS.
//     Create a module that exports a function that returns the square of a number.

// Exercise 2: ES6 Modules:
//     Objective: Practice using ES6 modules for importing and exporting.
//     Create a module that exports a function that returns the square of a number.
    
// Exercise 3: AMD:
//     Objective: Explore the Asynchronous Module Definition(AMD) pattern.
//     Create a module that exports a function that returns the square of a number.

// Exercise 4: UMD:
//     Objective: Learn about Universal Module Definition(UMD).
//     Create a module that exports a function that returns the square of a number.



