// Named Imports
import { add, subtract } from './math';

// Default Import
import multiply from './math';

const num1 = 10;
const num2 = 5;

const sum = add(num1, num2);
const difference = subtract(num1, num2);
const product = multiply(num1, num2);

console.log(`Sum: ${sum}`);
console.log(`Difference: ${difference}`);
console.log(`Product: ${product}`);
