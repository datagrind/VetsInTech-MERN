// Tasks:

// Exercise 1: Creating and Using Promises:
    // Objective: Learn to create and use promises to manage asynchronous tasks.
    // Create a promise that returns a string message. Print the message to the console using the then() method.

// Exercise 2: Chaining Promises:
    // Objective: Learn to chain promises to manage sequential asynchronous tasks.
    // Create a promise that returns a string message. Chain another promise that returns a string message after the first promise resolves. Print the final message to the console.

// Exercise 3: Parallel Promise Execution:
    // Objective: Learn to execute multiple promises in parallel.
    // Create 2 promises that return strings. Execute them in parallel and print the results to the console.
    
// Exercise 4: Async/Await Basics:
    // Objective: Learn to use async/await to manage asynchronous tasks.
    // Create an async function that returns a string message. Print the message to the console using await.
    
// Exercise 5: Error Handling with Async/Await:
    // Objective: Learn to handle errors in async/await functions.
    // Create an async function that throws an error. Use if/else to handle the error and print a custom message to the console.
    

