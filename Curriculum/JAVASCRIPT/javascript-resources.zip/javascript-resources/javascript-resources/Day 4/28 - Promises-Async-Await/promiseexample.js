// Function to fetch data from a remote server using a promise
function fetchData() {
    return new Promise((resolve, reject) => {
      // Simulate an HTTP request
      setTimeout(() => {
        const data = "Hello, this data is fetched with a promise!";
        resolve(data);
      }, 2000); // Simulate a 2-second delay
    });
  }
  
  // Function to update the HTML with the fetched data
  function updateDataInHTML(data) {
    const dataContainer = document.getElementById("data-container");
    dataContainer.textContent = data;
  }
  
  // Using the promise to fetch and display data
  fetchData()
    .then(data => {
      updateDataInHTML(data);
    })
    .catch(error => {
      console.error("Error:", error);
    });
  