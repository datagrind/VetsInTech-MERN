// A simple function that simulates an API request using Promises
function fetchData() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // Simulate a successful response
            resolve('Data fetched successfully');
            // Simulate an error response
            // reject('Error fetching data');
        }, 1000);
    });
}

// An async function that fetches and processes data
async function fetchAndProcessData() {
    try {
        document.getElementById('fetchStatus').textContent = 'Fetching data...';
        const data = await fetchData(); // Wait for the promise to resolve
        document.getElementById('fetchStatus').textContent = '';
        document.getElementById('fetchedData').textContent = 'Data: ' + data;
        document.getElementById('processedData').textContent = 'Processed Data: ' + data.toUpperCase();
    } catch (error) {
        document.getElementById('fetchStatus').textContent = 'An error occurred: ' + error;
    }
}

// Calling the async function when the page is loaded
window.addEventListener('load', fetchAndProcessData);
