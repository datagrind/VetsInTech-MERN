// Declare variables
var name = "Alice";
var age = 30;

// Access the output paragraph element by its ID
var outputElement = document.getElementById("output");

// Display variables on the HTML page
outputElement.innerHTML = "Name: " + name + "<br>";
outputElement.innerHTML += "Age: " + age;
