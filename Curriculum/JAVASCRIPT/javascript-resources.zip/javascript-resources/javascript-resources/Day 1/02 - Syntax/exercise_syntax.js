// Objective

// This exercise aims to familiarize you with the fundamental elements of JavaScript syntax by writing and testing JavaScript code.

// Tasks

// Task 1: Working with Statements and Variables
//     Create a file named javascriptsyntax.js.
//     Write statements to declare variables using var, let, and const. Assign different data types to these variables.
//     Use console.log() to output the values of these variables.

// Task 2: Utilizing Comments
//     Add both single-line and multi-line comments to your javascriptsyntax.js file, explaining what each block of code does.

// Task 3: Exploring Data Types
//     Create variables for different data types (number, string, boolean, array, and object).
//     Use console.log() to display the type of each variable using typeof.

// Task 4: Implementing Operators
//     Perform basic arithmetic operations and comparisons between variables.
//     Output the results using console.log().

// Task 5: Creating and Calling Functions
//     Write a function that takes a name as a parameter and logs a greeting.
//     Call this function with different names.

// Task 6: Conditional Statements
//     Write an if-else block that checks the value of a variable and logs different outputs.
//     Test this with different values.

// Task 7: Writing Loops
//     Write a for loop and a while loop that iterate a certain number of times, logging each iteration.

// Task 8: Working with Objects and Arrays
//     Create an object and an array, each with multiple elements.
//     Use console.log() to access and display specific elements from the object and array.