// Objective:

// Understand and apply different types of operators in JavaScript by completing a set of tasks that involve arithmetic, assignment, comparison, logical, and other operators.

// Tasks:

    // Arithmetic Operators:
    //     Perform basic arithmetic operations (addition, subtraction, multiplication, division, modulus) on two numbers and log the results to the console.

    // Assignment Operators:
    //     Initialize a variable and then use different assignment operators to update its value. Display each new value.

    // Comparison Operators:
    //     Compare two values using each comparison operator and log whether each statement is true or false.

    // Logical Operators:
    //     Create a few Boolean expressions using logical operators and evaluate their results.

    // Increment/Decrement Operators:
    //     Use the increment and decrement operators on a number and log the pre and post-increment/decrement values.

    // String Concatenation:
    //     Concatenate two strings using the + operator and log the result.

    // Ternary Operator:
    //     Use the ternary operator to create a simple conditional expression and log the output.

    // Typeof Operator:
    //     Use the typeof operator on different data types and log the results.

    // Bitwise Operators:
    //     Experiment with at least two bitwise operators and log the outcomes.

    // Elvis Operator (Optional - Advanced):
    //     Use the Elvis operator for conditional assignment and log the result.

    // Spread Operator (Optional - Advanced):
    //     Use the spread operator to combine two arrays or objects and log the result.

    // Object Destructuring (Optional - Advanced):
    //     Destructure an object into variables and log them.