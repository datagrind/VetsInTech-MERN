// Tasks:

// Exercise 1: Basic Template Literals:
// Objective: Practice creating strings with variable interpolation using template literals.

// Exercise 2: Multi-line Strings:
// Objective: Explore the use of template literals to create multi-line strings.

// Create a multi-line string using template literals. Demonstrate how it preserves line breaks and whitespace without needing escape characters.
// Exercise 3: Expression Interpolation

// Objective: Utilize template literals to embed expressions and perform calculations within strings.

// Write a template literal that includes mathematical calculations or string manipulations.For example, calculate the sum of two variables or combine two strings.
    
// Exercise 4: Tagged Template Literals:
// Objective: Understand how to use tagged template literals to customize string processing.

// Create a tag function that processes a template literal. Use it to modify the output, such as changing the case of strings or manipulating embedded expressions.
// Exercise 5: Creating HTML Templates:
// Objective: Use template literals to dynamically generate HTML content.

// Create an object representing a user with properties like name and age. Use a template literal to generate a piece of HTML that displays this information. This exercise simulates a common use case in web development.