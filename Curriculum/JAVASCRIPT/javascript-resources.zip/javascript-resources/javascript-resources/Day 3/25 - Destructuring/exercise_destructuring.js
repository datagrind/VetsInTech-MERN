// Tasks:

// Exercise 1: Basic Array Destructuring:
//     Objective: Learn to extract values from arrays and assign them to variables.
//     Create an array of numbers and use array destructuring to extract the values into variables.
        
// Exercise 2: Skipping Elements in Array Destructuring:
//     Objective: Practice skipping specific elements in an array while destructuring.
//     Using the same numbers array, extract only the first and third values, skipping the second.

// Exercise 3: Using Rest Parameters in Destructuring:
//     Objective: Understand how to capture the remaining elements in an array using the rest parameter.
//     Destructure the first element of the numbers array and use the rest parameter to get the remaining elements as a new array.

// Exercise 4: Basic Object Destructuring:
//     Objective: Extract properties from objects and assign them to variables.
//     Create an object representing a person with name and age properties. Use object destructuring to extract these values into variables.

// Exercise 5: Changing Variable Names in Object Destructuring:
//     Objective: Learn to rename variables while destructuring objects.
//     Using the same person object, destructure the properties into variables with different names (e.g., fullName for name and years for age).

// Exercise 6: Default Values in Object Destructuring:
//     Objective: Implement default values for properties that might be missing in the object.
//     Create a person object with only the name property. Destructure it by providing a default value for age.

// Exercise 7: Nested Object Destructuring:
//     Objective: Practice destructuring nested objects.
//     Create a student object with nested properties (info containing age and major). Destructure these nested properties into separate variables.

// Exercise 8: Function Parameter Destructuring:
//     Objective: Use destructuring directly in function parameters for readability and efficiency.
//     Write a function that takes an object as a parameter and destructures it within the function signature. Use this to print the person's details.