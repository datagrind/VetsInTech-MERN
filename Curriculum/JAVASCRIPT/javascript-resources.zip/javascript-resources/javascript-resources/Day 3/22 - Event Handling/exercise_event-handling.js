// Tasks:

// Create a HTML page named (exercise_event-handling.html) and add the elements needed for each task:

// Click and Double-Click Events:
//     Objective: Create a web page with two buttons.One button will change color when clicked, and the other will change color when double - clicked.
    
// Mouse Hover Effects::
//     Objective: Create an element that changes color when the mouse hovers over it and reverts to its original color when the mouse moves away.
    
// Keyboard Input Handling:
//     Objective: Detect and display the key pressed by the user in a text field.
    
// Event Bubbling: 
//     Create a nested structure(e.g., a div inside another div) and show how an event bubbles up from the inner element to the outer element.
    
// Event Delegation: 
//     Attach an event listener to a parent element and handle clicks on multiple child buttons using event delegation.