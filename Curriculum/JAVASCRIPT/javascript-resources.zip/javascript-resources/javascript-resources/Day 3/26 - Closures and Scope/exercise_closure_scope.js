// Tasks:

// Exercise 1: Global and Local Scope:
//     Objective: Understand the difference between global and local scope in JavaScript.
//     Create a variable in the global scope and another variable in the local scope.Try to access these variables from outside the scope where they were defined.What happens ?
        
// Exercise 2: Understanding Nested Scopes:
//     Objective: Learn how nested scopes work and the accessibility of variables.
//     Create an outerFunction with a local variable and an innerFunction nested inside it. Try accessing the outer variable from the inner function and vice versa.

// Exercise 3: Creating a Basic Closure:
//     Objective: Understand how closures retain access to the outer function’s scope after the outer function has returned.
//     Create a function that returns a function. Call the outer function and assign the result to a variable.Call this variable like a function.
    
// Exercise 4: Practical Use of Closures for Data Encapsulation:
//     Objective: Use closures to create private variables and functions.
//     Create a function that returns an object with methods to access and modify a private variable using closures.
    
// Exercise 5: Closures in Event Handlers:
//     Objective: Explore how closures capture the state at the time of function creation in event handlers.
//     Add an event listener to a button where the callback function uses a closure to remember the state of a variable when the listener was added.

// Exercise 6: Implementing Partial Functions Using Closures:
//     Objective: Use closures to create partially applied functions.
//     Write a function that returns another function, fixing some arguments in place. For instance, create a multiplyBy function that partially applies the multiplication factor.