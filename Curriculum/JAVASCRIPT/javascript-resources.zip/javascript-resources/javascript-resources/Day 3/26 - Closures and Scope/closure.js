// Initialize a container for our counters
const countersContainer = document.getElementById('counters');

// Function to create a new counter
function createCounter() {
  let count = 0;

  // Create elements for the counter
  const counterDiv = document.createElement('div');
  const countDisplay = document.createElement('span');
  const incrementButton = document.createElement('button');
  const decrementButton = document.createElement('button');

  countDisplay.textContent = count;
  incrementButton.textContent = 'Increment';
  decrementButton.textContent = 'Decrement';

  // Increment and decrement functions are closures
  function increment() {
    count++;
    countDisplay.textContent = count;
  }

  function decrement() {
    count--;
    countDisplay.textContent = count;
  }

  // Add click event listeners
  incrementButton.addEventListener('click', increment);
  decrementButton.addEventListener('click', decrement);

  // Append elements to the counter div
  counterDiv.appendChild(countDisplay);
  counterDiv.appendChild(incrementButton);
  counterDiv.appendChild(decrementButton);

  // Append the counter to the container
  countersContainer.appendChild(counterDiv);
}

// Create and display multiple counters
createCounter();
createCounter();
createCounter();
