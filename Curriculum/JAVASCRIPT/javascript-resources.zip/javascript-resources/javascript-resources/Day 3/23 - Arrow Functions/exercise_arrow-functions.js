// Tasks:

// Exercise 1: Basic Arrow Functions:
// Objective: Write and test different forms of arrow functions, including those with no parameters, one parameter, multiple parameters, and block bodies.

// Exercise 2: Implicit Return:
// Objective: Explore the implicit return feature of arrow functions in different scenarios.

//     Create several arrow functions that demonstrate implicit returns. Examples can include simple calculations, string manipulations, or array transformations.

// Exercise 3: this Binding in Arrow Functions:
// Objective: Understand how arrow functions handle the this keyword differently from regular functions.

//     Create an object with both traditional and arrow functions as methods.Demonstrate how this behaves differently in each case. Use console.log to show the value of this.
    
// Exercise 4: Arrow Functions as Callbacks:
// Objective: Use arrow functions as callbacks in array methods like map, filter, and reduce.

//     Given an array of numbers, use arrow functions with map, filter, and reduce to perform operations like squaring each number, filtering out even numbers, and calculating the sum of all numbers.
        
// Exercise 5: Limitations of Arrow Functions:
// Objective: Illustrate the limitations of arrow functions, particularly their lack of an arguments object.

// Exercise 6: Aguments in Arrow Functions:
// Write a traditional function that uses the arguments object and an arrow function that attempts to do the same. Show how the arrow function fails to access arguments.