// Objective

// Create a simple web application that allows users to enter the name of a Pokémon and fetch its details from the PokeAPI using Ajax.

//     Tasks:

//         We will be using: PokeAPI URL: https://pokeapi.co/api/v2/pokemon/
    
//     Setup HTML Structure:
//         Create an HTML file with an input field for the Pokémon name, a button to trigger the data fetch, and a section to display the Pokémon details.

//     JavaScript(Ajax Request): 
//       Create a JavaScript file that adds an event listener to the button.When clicked, it should use the XMLHttpRequest object to make a GET request to the PokeAPI with the entered Pokémon name.  

// Objective

// Modify the previous web application to use Axios for fetching Pokémon details from the PokeAPI.  

// Include Axios:

//     If you're working with a simple HTML/JS setup, you can include Axios via a CDN. Add the following line in the <head> section of your HTML:

//     html

//     <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

//     If you're using a package manager like npm, install Axios with npm install axios and import it in your JavaScript file.

// HTML Structure: Use the same HTML structure as in the previous exercise.

// JavaScript (Using Axios): In the JavaScript file, modify the event listener to use Axios for the API request.