document.addEventListener("DOMContentLoaded", function () {
    const quoteButton = document.getElementById("getQuote");
    const quoteText = document.getElementById("quote");

    quoteButton.addEventListener("click", function () {
        // Create an XMLHttpRequest object
        const xhr = new XMLHttpRequest();

        // Define the URL of the JSON API
        const apiUrl = "https://api.quotable.io/random";

        // Set up the request
        xhr.open("GET", apiUrl, true);

        // Define what happens when the request is completed
        xhr.onload = function () {
            if (xhr.status === 200) {
                // If the request was successful, parse the JSON response
                const quoteData = JSON.parse(xhr.responseText);
                const quote = quoteData.content;

                // Update the web page with the quote
                quoteText.innerHTML = `"${quote}" - ${quoteData.author}`;
            } else {
                // Handle errors if the request fails
                quoteText.innerHTML = "Failed to retrieve a quote.";
            }
        };

        // Send the request
        xhr.send();
    });
});
