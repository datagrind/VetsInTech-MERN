// Global Context
document.getElementById("globalOutput").textContent = this === window ? "In global context" : "Not in global context";

// Function Context
function showFunctionContext() {
    document.getElementById("functionOutput").textContent = this === window ? "In global context" : "Not in global context";
}
showFunctionContext();

// Object Method
const person = {
    name: "John",
    greet: function() {
        document.getElementById("objectOutput").textContent = "Hello, my name is " + this.name;
    }
};
person.greet();

// Event Handler
document.getElementById("myButton").addEventListener("click", function() {
    document.getElementById("eventOutput").textContent = "Button clicked. 'this' refers to the button element.";
});
