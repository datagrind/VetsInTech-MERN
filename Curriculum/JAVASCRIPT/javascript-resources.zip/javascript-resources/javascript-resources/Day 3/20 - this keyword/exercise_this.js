// Tasks:

// Exercise 1: Exploring this in Global Context

//     Objective: Understand how this behaves in the global scope.
//     Task: Write a simple script where you log the value of this in the global scope. Compare the output when running the script in a browser and in a Node.js environment.
//     Expected Outcome: Students should observe that this refers to the global object (window in a browser and global in Node.js).

// Exercise 2: Function Context and this

//     Objective: Learn how this changes based on how functions are called.
//     Task: Create two functions, one regular and one as a method of an object. Observe the value of this in both cases.
//         Example: function regularFunction() { console.log(this); } and const obj = { methodFunction() { console.log(this); } };
//     Expected Outcome: In regularFunction, this should refer to the global object, while in methodFunction, it should refer to obj.

// Exercise 3: this in Constructors

//     Objective: Demonstrate the use of this in constructors.
//     Task: Create a constructor function or class and instantiate an object. Inside the constructor, use this to assign properties.
//         Example: function Person(name) { this.name = name; } const alice = new Person('Alice');
//     Expected Outcome: Students will see that this in a constructor refers to the newly created instance (e.g., alice).

// Exercise 4: this in Event Handlers

//     Objective: Show how this behaves in DOM event handlers.
//     Task: Add an event listener to a DOM element and use this inside the event handler.
//         Example: document.getElementById('myButton').addEventListener('click', function() { console.log(this); });
//     Expected Outcome: this will refer to the DOM element that the event is bound to (myButton element).

// Exercise 5: Arrow Functions and this

//     Objective: Understand the behavior of this in arrow functions.
//     Task: Create an arrow function inside a method of an object and log the value of this.
//         Example: const obj = { method() { const arrowFunc = () => console.log(this); arrowFunc(); } }; obj.method();
//     Expected Outcome: Students should see that the arrow function does not have its own this, but inherits it from the enclosing context (obj).